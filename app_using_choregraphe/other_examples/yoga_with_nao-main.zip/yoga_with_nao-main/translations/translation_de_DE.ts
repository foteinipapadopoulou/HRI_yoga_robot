<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
    <context>
        <name>behavior_1/behavior.xar:/Krieger I Re/Say (2)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Gut gemacht! Virabhadrasana eins ist eine gute Übung, um die Beine, Arme und Schultern zu stärken und die Körperhaltung zu verbessern. Wir machen weiter mit Virabhadrasana zwei, bekannt als Krieger zwei.</source>
            <comment>Text</comment>
            <translation type="unfinished">Gut gemacht! Virabhadrasana eins ist eine gute Übung, um die Beine, Arme und Schultern zu stärken und die Körperhaltung zu verbessern. Wir machen weiter mit Virabhadrasana zwei, bekannt als Krieger zwei.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Outro/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Bis zum nächsten Mal!</source>
            <comment>Text</comment>
            <translation type="unfinished">Bis zum nächsten Mal!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Tadasana/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Gut gemacht! Tadasana ist eine wirksame Übung, um eure Körperhaltung und Entspannung zu verbessern. Wir machen weiter mit Virabhadrasana eins, bekannt als Krieger eins.</source>
            <comment>Text</comment>
            <translation type="unfinished">Gut gemacht! Tadasana ist eine wirksame Übung, um eure Körperhaltung und Entspannung zu verbessern. Wir machen weiter mit Virabhadrasana eins, bekannt als Krieger eins.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Jetzt kommen wir zurück zur Bergposition und dann wechseln wir die Seiten.</source>
            <comment>Text</comment>
            <translation type="unfinished">Jetzt kommen wir zurück zur Bergposition und dann wechseln wir die Seiten.</translation>
        </message>
    </context>
</TS>
